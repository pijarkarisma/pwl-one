<?php return array (
  'user-create' => 'App\\Http\\Livewire\\UserCreate',
  'user-edit' => 'App\\Http\\Livewire\\UserEdit',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);