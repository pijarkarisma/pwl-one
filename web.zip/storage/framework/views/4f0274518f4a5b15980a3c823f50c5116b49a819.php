

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="mb-4">
            <a href="<?php echo e(route('users.home')); ?>" class="text-primary">Back</a>
        </div>
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" value="<?php echo e($user->name); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" class="form-control" value="<?php echo e($user->email); ?>" disabled>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Lanjut\htdocs\advanced-web\resources\views/users/show.blade.php ENDPATH**/ ?>