

<?php $__env->startPush('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="mb-4">
            <a href="<?php echo e(route('users.home')); ?>" class="text-primary">Back</a>
        </div>
        <h1 class="mb-5">Edit Data</h1>
        <div class="row mb-4">
            <div class="col-md-6">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-edit', ['user' => $user])->html();
} elseif ($_instance->childHasBeenRendered('mt6G8NZ')) {
    $componentId = $_instance->getRenderedChildComponentId('mt6G8NZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('mt6G8NZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mt6G8NZ');
} else {
    $response = \Livewire\Livewire::mount('user-edit', ['user' => $user]);
    $html = $response->html();
    $_instance->logRenderedChild('mt6G8NZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Lanjut\htdocs\advanced-web\resources\views/users/edit.blade.php ENDPATH**/ ?>