

<?php $__env->startPush('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-5">CRUD with Livewire</h1>
        <div class="row mb-4">
            <div class="col-md-6">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-create')->html();
} elseif ($_instance->childHasBeenRendered('JjbxL3S')) {
    $componentId = $_instance->getRenderedChildComponentId('JjbxL3S');
    $componentTag = $_instance->getRenderedChildComponentTagName('JjbxL3S');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JjbxL3S');
} else {
    $response = \Livewire\Livewire::mount('user-create');
    $html = $response->html();
    $_instance->logRenderedChild('JjbxL3S', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
        <div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-table')->html();
} elseif ($_instance->childHasBeenRendered('Tu0iEg3')) {
    $componentId = $_instance->getRenderedChildComponentId('Tu0iEg3');
    $componentTag = $_instance->getRenderedChildComponentTagName('Tu0iEg3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Tu0iEg3');
} else {
    $response = \Livewire\Livewire::mount('user-table');
    $html = $response->html();
    $_instance->logRenderedChild('Tu0iEg3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="d-flex justify-content-center mt-5">
            <p class="text-center fw-normal">Pijar Karisma Prihanto | 201904560040</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Lanjut\htdocs\advanced-web\resources\views/users/index.blade.php ENDPATH**/ ?>